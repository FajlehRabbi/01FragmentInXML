package crm.exam.shahidur.fragment;

import android.app.FragmentManager;
import android.app.FragmentTransaction;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      /*  Frag1 f1 = new Frag1();
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.mymain,f1,"frag1");
        ft.commit();*/

    }

    public  void m1(View view){
        Frag1 f1 = new Frag1();
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        //ft.add(R.id.mymain,f1,"frag1");
        ft.replace(R.id.fragment,f1,"f1");
        ft.commit();
    }
    public  void m2(View view){
        Frag2 f2 = new Frag2();
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        //ft.add(R.id.mymain,f2,"frag1");
        ft.replace(R.id.fragment,f2,"f2");
        ft.commit();
    }
    public  void m3(View view){
        Frag3 f3 = new Frag3();
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        //ft.add(R.id.mymain,f2,"frag1");
        ft.replace(R.id.fragment,f3,"f3");
        ft.commit();
    }
}
